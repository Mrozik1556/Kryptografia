W pliku bin znajdują się gotowe programy 
1)Zadanie
żeby odpalić test zadania 1 należy włączyć plik test cryptfile.bat
i dla każdego kolejnego trybu szyfrowania podawać kolejno te same hasło

2)Zadanie
żeby odpalić odtwzracz należy włączyć plik mp3player.bat

Żeby zadania poprawnie działały należy mieć odpowiednio skonfigurowane jave
- ustawioną długość klucza kryptograficznego na długość nieskończoną
- dodany provider bouncy castle
- posiadanie biblioteki bouncy castle w folderze /%JAVA_HOME%/lib/ext