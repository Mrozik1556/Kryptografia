<?php

session_start();
if(!isset($_SESSION['usr']) or !isset($_SESSION['psw']))exit;
function check()
{
	$conn=new mysqli('127.0.0.1', 'sehost', 'ZFCAuvLbbPtDxj7b','krpt');
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	} 
	$sql = "SELECT salt FROM usr Where usr='".$_SESSION['usr']."' AND psw='".$_SESSION['psw']."'";
		$result = $conn->query($sql);
		if ($result->num_rows == 1) {
			return true;
		}
		else
		{
			return false;
		}
}

if(!check())exit;
echo "Witaj: ".$_SESSION['usr']."<br>";
?>
<a href="krypto.php">Nowy Przelew</a><br><a href="hist.php">Historia</a><br><a href="logout.php">Wyloguj</a>