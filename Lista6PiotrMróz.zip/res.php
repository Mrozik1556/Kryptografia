<?php
session_start();
if(!isset($_SESSION['usr']) or !isset($_SESSION['psw']))exit;
function check()
{
	$conn=new mysqli('127.0.0.1', 'sehost', 'ZFCAuvLbbPtDxj7b','krpt');
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	} 
	$sql = "SELECT salt FROM usr Where usr='".$_SESSION['usr']."' AND psw='".$_SESSION['psw']."'";
		$result = $conn->query($sql);
		if ($result->num_rows == 1) {
			return true;
		}
		else
		{
			return false;
		}
}

if(!check())exit;

$_SESSION["ad"]=$_POST["ad"];
$_SESSION["num"]=$_POST["num"];
$_SESSION["kw"]=$_POST["kw"];
?>
<body>
Potwierdź Wartosci <br>
<form action="wk.php" method="post" id="mform" name="mform" >
  Adresat: <input type="text" name="ad" id="ad" value="<?php echo $_POST["ad"] ?>" readonly><br>
  Numer: <input type="text" name="num" id="num" value="<?php echo $_POST["num"] ?>" readonly><br>
  Kwota: <input type="text" name="kw" id="kw" value="<?php echo $_POST["kw"] ?>" readonly><br>
  <input type="submit" id="sub">
</form>
<a href="main.php">Powrót</a>
</body>