Nowy urzytkownik<br>
<form action="new.php" method="post">
  Username: <input type="text" name="user"><br>
  Password: <input type="text" name="pasw"> <br>
  <input type="submit">