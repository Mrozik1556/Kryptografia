<body>
</body>
<script>

    $(".bold").

</script>
