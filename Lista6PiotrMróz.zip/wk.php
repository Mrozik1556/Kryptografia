<body>
<?php
session_start();

function check()
{
	$conn=new mysqli('127.0.0.1', 'sehost', 'ZFCAuvLbbPtDxj7b','krpt');
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	} 
	$sql = "SELECT salt FROM usr Where usr='".$_SESSION['usr']."' AND psw='".$_SESSION['psw']."'";
		$result = $conn->query($sql);
		if ($result->num_rows == 1) {
			return true;
		}
		else
		{
			return false;
		}
}

if(!check())exit;
if(!($_SESSION["ad"]==$_POST["ad"] && $_SESSION["num"]==$_POST["num"] && $_SESSION["kw"]==$_POST["kw"]))
{
	echo "Ktoś chciał cie oszukać!";
	exit;
}



$conn=new mysqli('127.0.0.1', 'sehost', 'ZFCAuvLbbPtDxj7b','krpt');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$sql = "INSERT INTO prw (usr,ad,num,kw)
VALUES ('".$_SESSION['usr']."', '".$_POST["ad"]."', '".$_POST["num"]."','".$_POST["kw"]."')";
if ($conn->query($sql) === TRUE) {
    echo "Prelew Wykonany pomyślnie<br>";
} else {
    echo "Nie wykonano przelewu spróbuj puźniej<br>";
}

echo "<div id='ad'>".$_POST["ad"]."</div><br>";
echo "<div id='num'>".$_POST["num"]."</div><br>";
echo "<div id='kw'>".$_POST["kw"]."</div><br>";

 ?>
 <br>
 <a href="main.php">Powrót</a>
 </body>