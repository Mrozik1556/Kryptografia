<?php
$usr=$_POST["user"];
$psw=$_POST["pasw"];
$salt=bin2hex( mcrypt_create_iv(64,MCRYPT_RAND)); 
$conn=new mysqli('127.0.0.1', 'sehost', 'ZFCAuvLbbPtDxj7b','krpt');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT id FROM usr Where usr='".$usr."'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
	echo "user exist<br>";
}

else{
$psw=hash('sha512',$salt.$psw);
$sql = "INSERT INTO usr (usr,psw,salt)
VALUES ('".$usr."', '".$psw."', '".$salt."')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
}
$conn->close();
?>
<a href="index.php">Powrót</a>