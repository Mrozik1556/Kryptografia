Zaloguj się<br>
<form action="log.php" method="post">
  Username: <input type="text" name="user"><br>
  Password: <input type="text" name="pasw"> <br>
  <input type="submit">
</form>
<br>
<a href="nnw.php">new user</a>