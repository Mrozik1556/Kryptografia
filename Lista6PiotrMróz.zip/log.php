<?php
function check()
{
	$conn=new mysqli('127.0.0.1', 'sehost', 'ZFCAuvLbbPtDxj7b','krpt');
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	} 
	$sql = "SELECT salt FROM usr Where usr='".$_SESSION['usr']."' AND psw='".$_SESSION['psw']."'";
		$result = $conn->query($sql);
		if ($result->num_rows == 1) {
			return 1;
		}
		else
		{
			return 0;
		}
}




$usr=$_POST["user"];
$psw=$_POST["pasw"];
$conn=new mysqli('127.0.0.1', 'sehost', 'ZFCAuvLbbPtDxj7b','krpt');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT salt FROM usr Where usr='".$usr."'";

$result = $conn->query($sql);
if ($result->num_rows == 1) {

		while($row = $result->fetch_assoc()) {	
			$psw=hash('sha512',$row["salt"].$psw);
			
		}
		$sql = "SELECT salt FROM usr Where usr='".$usr."' AND psw='".$psw."'";
		$result = $conn->query($sql);
		if ($result->num_rows == 1) {
			session_start();
			$_SESSION['psw'] = $psw;
			$_SESSION['usr'] = $usr;
			echo "Poprawnie zalogowane<br><a href='main.php'>Dalej</a>";
		}
		else
		{
			echo "Problem przy logowaniu spróbuj ponownie<br><a href='index.php'>Powrót</a>";
		}

}
else
	echo "Problem przy logowaniu spróbuj ponownie<br><a href='index.php'>Powrót</a>";

$conn->close();
?>