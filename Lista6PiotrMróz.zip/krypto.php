<?php
session_start();
if(!isset($_SESSION['usr']) or !isset($_SESSION['psw']))exit;
function check()
{
	$conn=new mysqli('127.0.0.1', 'sehost', 'ZFCAuvLbbPtDxj7b','krpt');
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	} 
	$sql = "SELECT salt FROM usr Where usr='".$_SESSION['usr']."' AND psw='".$_SESSION['psw']."'";
		$result = $conn->query($sql);
		if ($result->num_rows == 1) {
			return true;
		}
		else
		{
			return false;
		}
}
if(!check())exit;
$_SESSION["ad"]="";
$_SESSION["num"]="";
$_SESSION["kw"]="";
?>
<body>
Wpisz Dane przelewu<br>
<form action="res.php" method="post" id="mform" name="mform" >
  Adresat: <input type="text" name="ad" id="ad"><br>
  Numer: <input type="text" name="num" id="num"><br>
  Kwota: <input type="text" name="kw" id="kw"><br>
  <input type="submit" id="sub">
</form>
<a href="main.php">Powrót</a>
</body>