<?php 
session_start();
session_destroy();?>
Wylogowano<br>
<a href="index.php">Strona główna</a>